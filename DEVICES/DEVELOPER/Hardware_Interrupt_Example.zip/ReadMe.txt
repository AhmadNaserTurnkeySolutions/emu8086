The virtual device code is written in Visual Basic 6.0

While the "Custom_Interrupt_up1.asm" is running on the emulator,
it should be possible to see how the message appears on the
emulator's screen right after the "Trigger INT 90h" button is clicked
on the virtual device.

The format of "c:\emu8086.hw" is quite simple. Every byte corresponds to
hardware interrupt we want to trigger. The emulator sets this byte
back to zero, after it has received the command to trigger an
interrupt. Interrupt Flag must be set to 1 (default) for the emulator
to react on hardware interrupts.
